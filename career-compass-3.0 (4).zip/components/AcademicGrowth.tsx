
import React from 'react';
import { AcademicGrowth as AcademicGrowthType } from '../types';
import { BookOpen, Target, Award, ArrowUpCircle, AlertCircle, CheckCircle2 } from 'lucide-react';

interface AcademicGrowthProps {
  data: AcademicGrowthType;
}

const AcademicGrowth: React.FC<AcademicGrowthProps> = ({ data }) => {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'text-red-400 border-red-900/30 bg-red-900/10';
      case 'Medium': return 'text-yellow-400 border-yellow-900/30 bg-yellow-900/10';
      case 'Low': return 'text-blue-400 border-blue-900/30 bg-blue-900/10';
      default: return 'text-slate-400 border-slate-700 bg-slate-800/50';
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* CGPA Summary Header */}
      <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 shadow-xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
          <Award size={120} className="text-white" />
        </div>
        <div className="relative z-10">
          <h2 className="text-xl font-bold text-white flex items-center gap-2 mb-4">
            <Award className="text-yellow-500" size={24} />
            CGPA & Performance Analysis
          </h2>
          <p className="text-slate-300 leading-relaxed mb-6">
            {data.cgpaAnalysis}
          </p>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-1">
                <Target size={14} className="text-blue-500" />
                Target Milestones
              </h3>
              <ul className="space-y-2">
                {data.targetMilestones.map((m, i) => (
                  <li key={i} className="text-sm text-slate-200 flex items-start gap-2">
                    <CheckCircle2 size={14} className="text-green-500 mt-0.5 flex-shrink-0" />
                    {m}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-1">
                <BookOpen size={14} className="text-purple-500" />
                Pro Study Tips
              </h3>
              <ul className="space-y-2">
                {data.studyTips.map((tip, i) => (
                  <li key={i} className="text-sm text-slate-200 flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-purple-500 mt-1.5 flex-shrink-0" />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Subject-Specific Strategies */}
      <div>
        <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2">
          <ArrowUpCircle className="text-green-500" size={20} />
          Subject Focus & Booster Strategies
        </h3>
        <div className="grid md:grid-cols-2 gap-4">
          {data.subjectFocus.map((item, idx) => (
            <div 
              key={idx} 
              className="bg-slate-900 border border-slate-800 p-5 rounded-2xl hover:border-slate-700 transition-all duration-300 group hover:-translate-y-1"
            >
              <div className="flex justify-between items-start mb-3">
                <h4 className="font-bold text-slate-100 group-hover:text-blue-400 transition-colors">{item.subject}</h4>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${getPriorityColor(item.priority)}`}>
                  {item.priority} Priority
                </span>
              </div>
              <div className="mb-4">
                <div className="text-[10px] text-slate-500 uppercase font-bold mb-1">Current State</div>
                <p className="text-sm text-slate-400">{item.currentPerformance}</p>
              </div>
              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                <div className="text-[10px] text-blue-500 uppercase font-bold mb-1 flex items-center gap-1">
                  <AlertCircle size={10} /> Strategy to Boost
                </div>
                <p className="text-sm text-slate-300 italic">{item.improvementStrategy}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AcademicGrowth;
